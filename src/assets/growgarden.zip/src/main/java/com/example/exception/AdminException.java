package com.example.exception;

public class AdminException extends RuntimeException {

	public AdminException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
