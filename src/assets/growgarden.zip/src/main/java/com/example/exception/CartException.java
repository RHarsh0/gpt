package com.example.exception;

public class CartException extends RuntimeException{

	  public CartException(String msg) {
		  super(msg);
	  }
}