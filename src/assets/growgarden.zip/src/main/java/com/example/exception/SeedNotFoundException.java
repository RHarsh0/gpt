package com.example.exception;

public class SeedNotFoundException extends RuntimeException{

	public SeedNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public SeedNotFoundException(String message) {
		super(message);
	}
	
	
}