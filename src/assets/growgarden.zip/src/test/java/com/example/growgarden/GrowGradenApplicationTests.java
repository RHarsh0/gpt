package com.example.growgarden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrowGradenApplicationTests {

	@Test
	void contextLoads() {
	}

}
